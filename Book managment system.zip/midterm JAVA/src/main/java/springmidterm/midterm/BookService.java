package springmidterm.midterm;



import java.util.List;


public interface BookService {
	List<Book> getAllStudents();

	Book saveStudent(Book student);

	Book getStudentById(Long id);

	Book updateStudent(Book student);

	void deleteStudentById(Long id);
}
