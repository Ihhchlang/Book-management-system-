package springmidterm.midterm;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImp implements BookService{

    private BookRepository studentRepository;

    public BookServiceImp(BookRepository studentRepository) {
        super();
        this.studentRepository = studentRepository;
    }

    @Override
    public List<Book> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Book saveStudent(Book student) {
        return studentRepository.save(student);
    }

    @Override
    public Book getStudentById(Long id) {
        return studentRepository.getById(Math.toIntExact(id));
    }

    @Override
    public Book updateStudent(Book student) {
        return studentRepository.save(student);
    }

    @Override
    public void deleteStudentById(Long id) {
        studentRepository.deleteById(Math.toIntExact(id));
    }

}
