package springmidterm.midterm;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class BookController {
	
	private BookService bookService;

	public BookController(BookService studentService1) {
		super();
		this.bookService = studentService1;
	}
	
	// handler method to handle list students and return mode and view
	@GetMapping("/books")
	public String listStudents(Model model) {
		model.addAttribute("students", bookService.getAllStudents());
		return "books";
	}
	
	@GetMapping("/books/new")
	public String createStudentForm(Model model) {
		
		// create student object to hold student form data
		Book student = new Book();
		model.addAttribute("student", student);
		return "create_book";
		
	}
	
	@PostMapping("/books")
	public String saveStudent(@ModelAttribute("student") Book book) {
		bookService.saveStudent(book);
		return "redirect:/books";
	}
	
	@GetMapping("/books/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) {
		model.addAttribute("student", bookService.getStudentById(id));
		return "edit_book";
	}

	@PostMapping("/books/{id}")
	public String updateStudent(@PathVariable Long id,
			@ModelAttribute("student") Book student,
			Model model) {
		
		// get student from database by id
		Book existingBook = bookService.getStudentById(id);
		existingBook.setId(id);
		existingBook.setTitle(student.getTitle());
		existingBook.setAuthor(student.getAuthor());
		existingBook.setDescription(student.getDescription());
		existingBook.setCost(student.getCost());
		
		// save updated student object
		bookService.updateStudent(existingBook);
		return "redirect:/books";
	}
	
	// handler method to handle delete student request
	
	@GetMapping("/books/{id}")
	public String deleteStudent(@PathVariable Long id) {
		bookService.deleteStudentById(id);
		return "redirect:/books";
	}
	
}
